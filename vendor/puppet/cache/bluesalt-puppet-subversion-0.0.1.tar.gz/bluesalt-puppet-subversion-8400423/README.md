# subversion Puppet Module for Boxen

## Usage


```puppet
include subversion
```

## Required Puppet Modules

* `boxen`
* `homebrew`
